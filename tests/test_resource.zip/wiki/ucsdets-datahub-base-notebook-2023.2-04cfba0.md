|    | createdAt           | CMD                    | hSize   | hcumSize   | elapsed   | Tags                                             |
|---:|:--------------------|:-----------------------|:--------|:-----------|:----------|:-------------------------------------------------|
|  0 | 2021-07-25 17:05:15 | `WORKDIR /home/jovyan` | 0 B     | 4.0 GB     |           | ['jupyter/datascience-notebook:python-3.9.5']    |
| 21 | 2023-05-12 03:35:29 | `WORKDIR /home/jovyan` | 0 B     | 4.9 GB     | 0s        | ['ucsdets/datahub-base-notebook:2023.2-04cfba0'] |

## Python Version

```
Python 3.9.5
```



## pip Packages

<details>
<summary>Details</summary>

```
Package                       Version
----------------------------- -------------------
alembic                       1.10.4
altair                        4.1.0
anyio                         3.2.1
appdirs                       1.4.4
argon2-cffi                   20.1.0
async-generator               1.10
attrs                         21.2.0
Babel                         2.9.1
backcall                      0.2.0
backports.functools-lru-cache 1.6.4
beautifulsoup4                4.9.3
bleach                        3.3.1
blinker                       1.4
bokeh                         2.3.3
Bottleneck                    1.3.2
brotlipy                      0.7.0
cached-property               1.5.2
certifi                       2023.5.7
certipy                       0.1.3
cffi                          1.14.6
chardet                       4.0.0
charset-normalizer            2.0.0
click                         8.0.1
cloudpickle                   1.6.0
colorama                      0.4.6
comm                          0.1.3
conda                         4.10.2
conda-package-handling        1.7.3
cryptography                  3.4.7
cycler                        0.10.0
Cython                        0.29.24
cytoolz                       0.11.0
dask                          2021.6.2
debugpy                       1.6.7
decorator                     5.0.9
defusedxml                    0.7.1
dill                          0.3.4
distributed                   2021.6.2
entrypoints                   0.3
env-backup                    0.0.3
exceptiongroup                1.1.1
fastjsonschema                2.16.3
fsspec                        2021.7.0
gitdb                         4.0.10
GitPython                     3.1.31
gmpy2                         2.1.0b5
GPUtil                        1.4.0
greenlet                      1.1.0
h5py                          3.3.0
HeapDict                      1.0.1
idna                          3.1
imagecodecs                   2021.6.8
imageio                       2.9.0
importlib-metadata            6.6.0
iniconfig                     2.0.0
ipykernel                     6.17.1
ipympl                        0.7.0
ipython                       7.25.0
ipython-genutils              0.2.0
ipywidgets                    7.6.3
jedi                          0.18.0
Jinja2                        3.0.1
joblib                        1.0.1
json5                         0.9.5
jsonschema                    3.2.0
jupyter-client                7.4.9
jupyter-core                  4.12.0
jupyter-events                0.6.3
jupyter-server                1.24.0
jupyter-server-mathjax        0.2.6
jupyter-server-terminals      0.4.4
jupyter-telemetry             0.1.0
jupyterhub                    1.4.1
jupyterlab                    3.0.16
jupyterlab-fasta              3.2.0
jupyterlab-geojson            3.3.1
jupyterlab-git                0.39.3
jupyterlab-github             3.0.1
jupyterlab-latex              3.1.0
jupyterlab-pullrequests       3.0.2
jupyterlab-pygments           0.1.2
jupyterlab-server             2.6.1
jupyterlab-widgets            1.0.0
kiwisolver                    1.3.1
llvmlite                      0.36.0
locket                        0.2.0
Mako                          1.1.4
mamba                         0.15.2
MarkupSafe                    2.0.1
matplotlib                    3.4.2
matplotlib-inline             0.1.2
mistune                       2.0.5
mock                          4.0.3
mpmath                        1.2.1
msgpack                       1.0.2
nbclassic                     0.3.1
nbclient                      0.6.3
nbconvert                     7.2.1
nbdime                        3.2.1
nbformat                      5.8.0
nbgitpuller                   1.1.2.dev0
nbgrader                      0.8.1
nbresuse                      0.2.0
nest-asyncio                  1.5.6
networkx                      2.5
nltk                          3.8.1
notebook                      6.4.0
numba                         0.53.1
numexpr                       2.7.3
numpy                         1.21.1
oauthlib                      3.1.1
olefile                       0.46
packaging                     21.0
pamela                        1.0.0
pandas                        1.5.3
pandocfilters                 1.4.2
parso                         0.8.2
partd                         1.2.0
patsy                         0.5.1
pexpect                       4.8.0
pickleshare                   0.7.5
Pillow                        8.3.1
pip                           21.1.3
platformdirs                  3.5.1
pluggy                        1.0.0
pooch                         1.4.0
prometheus-client             0.11.0
prompt-toolkit                3.0.19
protobuf                      3.17.2
psutil                        5.8.0
ptyprocess                    0.7.0
pycosat                       0.6.3
pycparser                     2.20
pycurl                        7.43.0.6
Pygments                      2.9.0
PyJWT                         2.1.0
pyOpenSSL                     20.0.1
pyparsing                     2.4.7
pyrsistent                    0.17.3
PySocks                       1.7.1
pytest                        7.3.1
python-dateutil               2.8.2
python-editor                 1.0.4
python-json-logger            2.0.7
pytz                          2021.1
PyWavelets                    1.1.1
PyYAML                        5.4.1
pyzmq                         25.0.2
rapidfuzz                     3.0.0
regex                         2023.5.5
requests                      2.26.0
requests-unixsocket           0.2.0
rfc3339-validator             0.1.4
rfc3986-validator             0.1.1
rise                          5.7.1
rpy2                          3.4.5
ruamel-yaml-conda             0.15.80
ruamel.yaml                   0.17.10
ruamel.yaml.clib              0.2.2
scikit-image                  0.18.2
scikit-learn                  0.24.2
scipy                         1.7.0
seaborn                       0.11.1
Send2Trash                    1.7.1
setuptools                    49.6.0.post20210108
simplegeneric                 0.8.1
six                           1.16.0
smmap                         5.0.0
sniffio                       1.2.0
sortedcontainers              2.4.0
soupsieve                     2.0.1
SQLAlchemy                    1.4.22
statsmodels                   0.12.2
sympy                         1.8
tables                        3.6.1
tblib                         1.7.0
terminado                     0.10.1
testpath                      0.5.0
threadpoolctl                 2.2.0
tifffile                      2021.7.2
timeout-decorator             0.5.0
tinycss2                      1.2.1
tomli                         2.0.1
toolz                         0.11.1
tornado                       6.3.1
tqdm                          4.61.2
traitlets                     5.1.1
typing-extensions             4.5.0
tzlocal                       2.1
urllib3                       1.26.6
wcwidth                       0.2.5
webencodings                  0.5.1
websocket-client              0.57.0
wheel                         0.36.2
widgetsnbextension            3.5.1
xlrd                          2.0.1
zict                          2.0.0
zipp                          3.5.0
```
</details>




## Conda Info

```

     active environment : None
       user config file : /home/jovyan/.condarc
 populated config files : /opt/conda/.condarc
          conda version : 4.10.2
    conda-build version : not installed
         python version : 3.9.5.final.0
       virtual packages : __linux=5.15.0=0
                          __glibc=2.31=0
                          __unix=0=0
                          __archspec=1=x86_64
       base environment : /opt/conda  (writable)
      conda av data dir : /opt/conda/etc/conda
  conda av metadata url : None
           channel URLs : https://conda.anaconda.org/conda-forge/linux-64
                          https://conda.anaconda.org/conda-forge/noarch
          package cache : /opt/conda/pkgs
                          /home/jovyan/.conda/pkgs
       envs directories : /opt/conda/envs
                          /home/jovyan/.conda/envs
               platform : linux-64
             user-agent : conda/4.10.2 requests/2.26.0 CPython/3.9.5 Linux/5.15.0-1037-azure ubuntu/20.04.2 glibc/2.31
                UID:GID : 1000:100
             netrc file : None
           offline mode : False
```



## Conda Packages

<details>
<summary>Details</summary>

```
# packages in environment at /opt/conda:
#
# Name                    Version                   Build  Channel
_libgcc_mutex             0.1                 conda_forge    conda-forge
_openmp_mutex             4.5                       1_gnu    conda-forge
_r-mutex                  1.0.1               anacondar_1    conda-forge
alembic                   1.10.4                   pypi_0    pypi
altair                    4.1.0                      py_1    conda-forge
anyio                     3.2.1            py39hf3d152e_0    conda-forge
appdirs                   1.4.4              pyh9f0ad1d_0    conda-forge
argon2-cffi               20.1.0           py39h3811e60_2    conda-forge
async_generator           1.10                       py_0    conda-forge
attrs                     21.2.0             pyhd8ed1ab_0    conda-forge
babel                     2.9.1              pyh44b312d_0    conda-forge
backcall                  0.2.0              pyh9f0ad1d_0    conda-forge
backports                 1.0                        py_2    conda-forge
backports.functools_lru_cache 1.6.4              pyhd8ed1ab_0    conda-forge
beautifulsoup4            4.9.3              pyhb0f4dca_0    conda-forge
binutils_impl_linux-64    2.36.1               h193b22a_1    conda-forge
binutils_linux-64         2.36                hf3e587d_33    conda-forge
blas                      1.1                    openblas    conda-forge
bleach                    3.3.1              pyhd8ed1ab_0    conda-forge
blinker                   1.4                        py_1    conda-forge
blosc                     1.21.0               h9c3ff4c_0    conda-forge
bokeh                     2.3.3            py39hf3d152e_0    conda-forge
bottleneck                1.3.2            py39hce5d2b2_3    conda-forge
brotli                    1.0.9                h7f98852_5    conda-forge
brotli-bin                1.0.9                h7f98852_5    conda-forge
brotlipy                  0.7.0           py39h3811e60_1001    conda-forge
brunsli                   0.1                  h9c3ff4c_0    conda-forge
bwidget                   1.9.14               ha770c72_0    conda-forge
bzip2                     1.0.8                h7f98852_4    conda-forge
c-ares                    1.17.1               h7f98852_1    conda-forge
ca-certificates           2023.5.7             hbcca054_0    conda-forge
cached-property           1.5.2                hd8ed1ab_1    conda-forge
cached_property           1.5.2              pyha770c72_1    conda-forge
cairo                     1.16.0            h6cf1ce9_1008    conda-forge
certifi                   2023.5.7           pyhd8ed1ab_0    conda-forge
certipy                   0.1.3                      py_0    conda-forge
cffi                      1.14.6           py39he32792d_0    conda-forge
cfitsio                   3.470                hb418390_7    conda-forge
chardet                   4.0.0            py39hf3d152e_1    conda-forge
charls                    2.2.0                h9c3ff4c_0    conda-forge
charset-normalizer        2.0.0              pyhd8ed1ab_0    conda-forge
click                     8.0.1            py39hf3d152e_0    conda-forge
cloudpickle               1.6.0                      py_0    conda-forge
colorama                  0.4.6                    pypi_0    pypi
comm                      0.1.3                    pypi_0    pypi
conda                     4.10.2           py39hf3d152e_0    conda-forge
conda-package-handling    1.7.3            py39h3811e60_0    conda-forge
configurable-http-proxy   4.5.0           node15_he6ea98c_0    conda-forge
cryptography              3.4.7            py39hbca0aa6_0    conda-forge
curl                      7.77.0               hea6ffbf_0    conda-forge
cycler                    0.10.0                     py_2    conda-forge
cython                    0.29.24          py39he80948d_0    conda-forge
cytoolz                   0.11.0           py39h3811e60_3    conda-forge
dask                      2021.6.2           pyhd8ed1ab_0    conda-forge
dask-core                 2021.6.2           pyhd8ed1ab_0    conda-forge
debugpy                   1.6.7                    pypi_0    pypi
decorator                 5.0.9              pyhd8ed1ab_0    conda-forge
defusedxml                0.7.1              pyhd8ed1ab_0    conda-forge
dill                      0.3.4              pyhd8ed1ab_0    conda-forge
distributed               2021.6.2         py39hf3d152e_0    conda-forge
entrypoints               0.3             pyhd8ed1ab_1003    conda-forge
env-backup                0.0.3                    pypi_0    pypi
exceptiongroup            1.1.1                    pypi_0    pypi
fastjsonschema            2.16.3                   pypi_0    pypi
font-ttf-dejavu-sans-mono 2.37                 hab24e00_0    conda-forge
font-ttf-inconsolata      3.000                h77eed37_0    conda-forge
font-ttf-source-code-pro  2.038                h77eed37_0    conda-forge
font-ttf-ubuntu           0.83                 hab24e00_0    conda-forge
fontconfig                2.13.1            hba837de_1005    conda-forge
fonts-conda-ecosystem     1                             0    conda-forge
fonts-conda-forge         1                             0    conda-forge
freetype                  2.10.4               h0708190_1    conda-forge
fribidi                   1.0.10               h36c2ea0_0    conda-forge
fsspec                    2021.7.0           pyhd8ed1ab_0    conda-forge
gcc_impl_linux-64         9.3.0               h70c0ae5_19    conda-forge
gcc_linux-64              9.3.0               hf25ea35_33    conda-forge
gettext                   0.19.8.1          h0b5b191_1005    conda-forge
gfortran_impl_linux-64    9.3.0               hc4a2995_19    conda-forge
gfortran_linux-64         9.3.0               hdc58fab_33    conda-forge
giflib                    5.2.1                h36c2ea0_2    conda-forge
gitdb                     4.0.10                   pypi_0    pypi
gitpython                 3.1.31                   pypi_0    pypi
gmp                       6.2.1                h58526e2_0    conda-forge
gmpy2                     2.1.0b5          py39h78fa15d_0    conda-forge
gputil                    1.4.0                    pypi_0    pypi
graphite2                 1.3.13            h58526e2_1001    conda-forge
greenlet                  1.1.0            py39he80948d_0    conda-forge
gsl                       2.6                  he838d99_2    conda-forge
gxx_impl_linux-64         9.3.0               hd87eabc_19    conda-forge
gxx_linux-64              9.3.0               h3fbe746_33    conda-forge
h5py                      3.3.0           nompi_py39h98ba4bc_100    conda-forge
harfbuzz                  2.8.2                h83ec7ef_0    conda-forge
hdf5                      1.10.6          nompi_h6a2412b_1114    conda-forge
heapdict                  1.0.1                      py_0    conda-forge
icu                       68.1                 h58526e2_0    conda-forge
idna                      3.1                pyhd3deb0d_0    conda-forge
imagecodecs               2021.6.8         py39h44211f0_0    conda-forge
imageio                   2.9.0                      py_0    conda-forge
importlib-metadata        6.6.0                    pypi_0    pypi
iniconfig                 2.0.0                    pypi_0    pypi
ipykernel                 6.17.1                   pypi_0    pypi
ipympl                    0.7.0              pyhd8ed1ab_0    conda-forge
ipython                   7.25.0           py39hef51801_1    conda-forge
ipython_genutils          0.2.0                      py_1    conda-forge
ipywidgets                7.6.3              pyhd3deb0d_0    conda-forge
jbig                      2.1               h7f98852_2003    conda-forge
jedi                      0.18.0           py39hf3d152e_2    conda-forge
jinja2                    3.0.1              pyhd8ed1ab_0    conda-forge
joblib                    1.0.1              pyhd8ed1ab_0    conda-forge
jpeg                      9d                   h36c2ea0_0    conda-forge
json5                     0.9.5              pyh9f0ad1d_0    conda-forge
jsonschema                3.2.0              pyhd8ed1ab_3    conda-forge
jupyter-client            7.4.9                    pypi_0    pypi
jupyter-core              4.12.0                   pypi_0    pypi
jupyter-events            0.6.3                    pypi_0    pypi
jupyter-server            1.24.0                   pypi_0    pypi
jupyter-server-mathjax    0.2.6                    pypi_0    pypi
jupyter-server-terminals  0.4.4                    pypi_0    pypi
jupyter_telemetry         0.1.0              pyhd8ed1ab_1    conda-forge
jupyterhub                1.4.1            py39hf3d152e_0    conda-forge
jupyterhub-base           1.4.1            py39hf3d152e_0    conda-forge
jupyterlab                3.0.16             pyhd8ed1ab_0    conda-forge
jupyterlab-fasta          3.2.0                    pypi_0    pypi
jupyterlab-geojson        3.3.1                    pypi_0    pypi
jupyterlab-git            0.39.3                   pypi_0    pypi
jupyterlab-github         3.0.1                    pypi_0    pypi
jupyterlab-latex          3.1.0                    pypi_0    pypi
jupyterlab-pullrequests   3.0.2                    pypi_0    pypi
jupyterlab_pygments       0.1.2              pyh9f0ad1d_0    conda-forge
jupyterlab_server         2.6.1              pyhd8ed1ab_0    conda-forge
jupyterlab_widgets        1.0.0              pyhd8ed1ab_1    conda-forge
jxrlib                    1.1                  h7f98852_2    conda-forge
kernel-headers_linux-64   2.6.32              he073ed8_14    conda-forge
kiwisolver                1.3.1            py39h1a9c180_1    conda-forge
krb5                      1.19.1               hcc1bbae_0    conda-forge
lcms2                     2.12                 hddcbb42_0    conda-forge
ld_impl_linux-64          2.36.1               hea4e1c9_1    conda-forge
lerc                      2.2.1                h9c3ff4c_0    conda-forge
libaec                    1.0.5                h9c3ff4c_0    conda-forge
libarchive                3.5.1                hccf745f_2    conda-forge
libblas                   3.9.0                9_openblas    conda-forge
libbrotlicommon           1.0.9                h7f98852_5    conda-forge
libbrotlidec              1.0.9                h7f98852_5    conda-forge
libbrotlienc              1.0.9                h7f98852_5    conda-forge
libcblas                  3.9.0                9_openblas    conda-forge
libcurl                   7.77.0               h2574ce0_0    conda-forge
libdeflate                1.7                  h7f98852_5    conda-forge
libedit                   3.1.20191231         he28a2e2_2    conda-forge
libev                     4.33                 h516909a_1    conda-forge
libffi                    3.3                  h58526e2_2    conda-forge
libgcc-devel_linux-64     9.3.0               h7864c58_19    conda-forge
libgcc-ng                 12.2.0              h65d4601_19    conda-forge
libgfortran-ng            9.4.0                h69a702a_0    conda-forge
libgfortran5              9.4.0                h62347ff_0    conda-forge
libgit2                   1.1.1                hee63804_1    conda-forge
libglib                   2.68.3               h3e27bee_0    conda-forge
libgomp                   12.2.0              h65d4601_19    conda-forge
libiconv                  1.16                 h516909a_0    conda-forge
liblapack                 3.9.0                9_openblas    conda-forge
libllvm10                 10.0.1               he513fc3_3    conda-forge
libnghttp2                1.43.0               h812cca2_0    conda-forge
libopenblas               0.3.15          pthreads_h8fe5266_1    conda-forge
libpng                    1.6.37               h21135ba_2    conda-forge
libprotobuf               3.17.2               h780b84a_1    conda-forge
libsodium                 1.0.18               h36c2ea0_1    conda-forge
libsolv                   0.7.19               h780b84a_5    conda-forge
libssh2                   1.9.0                ha56f1ee_6    conda-forge
libstdcxx-devel_linux-64  9.3.0               hb016644_19    conda-forge
libstdcxx-ng              9.3.0               h6de172a_19    conda-forge
libtiff                   4.3.0                hf544144_1    conda-forge
libuuid                   2.32.1            h7f98852_1000    conda-forge
libuv                     1.41.1               h7f98852_0    conda-forge
libwebp-base              1.2.0                h7f98852_2    conda-forge
libxcb                    1.13              h7f98852_1003    conda-forge
libxml2                   2.9.12               h72842e0_0    conda-forge
libzopfli                 1.0.3                h9c3ff4c_0    conda-forge
llvmlite                  0.36.0           py39h1bbdace_0    conda-forge
locket                    0.2.0                      py_2    conda-forge
lz4-c                     1.9.3                h9c3ff4c_0    conda-forge
lzo                       2.10              h516909a_1000    conda-forge
make                      4.3                  hd18ef5c_1    conda-forge
mako                      1.1.4              pyh44b312d_0    conda-forge
mamba                     0.15.2           py39h951de11_0    conda-forge
markupsafe                2.0.1            py39h3811e60_0    conda-forge
matplotlib-base           3.4.2            py39h2fa2bec_0    conda-forge
matplotlib-inline         0.1.2              pyhd8ed1ab_2    conda-forge
mistune                   2.0.5                    pypi_0    pypi
mock                      4.0.3            py39hf3d152e_1    conda-forge
mpc                       1.1.0             h04dde30_1009    conda-forge
mpfr                      4.0.2                he80fd80_1    conda-forge
mpmath                    1.2.1              pyhd8ed1ab_0    conda-forge
msgpack-python            1.0.2            py39h1a9c180_1    conda-forge
nbclassic                 0.3.1              pyhd8ed1ab_1    conda-forge
nbclient                  0.6.3                    pypi_0    pypi
nbconvert                 7.2.1                    pypi_0    pypi
nbdime                    3.2.1                    pypi_0    pypi
nbformat                  5.8.0                    pypi_0    pypi
nbgitpuller               1.1.2.dev0               pypi_0    pypi
nbgrader                  0.8.1                    pypi_0    pypi
nbresuse                  0.2.0                    pypi_0    pypi
ncurses                   6.2                  h58526e2_4    conda-forge
nest-asyncio              1.5.6                    pypi_0    pypi
networkx                  2.5                        py_0    conda-forge
nltk                      3.8.1                    pypi_0    pypi
nodejs                    15.14.0              h92b4a50_0    conda-forge
notebook                  6.4.0              pyha770c72_0    conda-forge
numba                     0.53.1           py39h56b8d98_1    conda-forge
numexpr                   2.7.3            py39hde0f152_0    conda-forge
numpy                     1.21.1           py39hdbf815f_0    conda-forge
oauthlib                  3.1.1              pyhd8ed1ab_0    conda-forge
olefile                   0.46               pyh9f0ad1d_1    conda-forge
openblas                  0.3.15          pthreads_h4748800_1    conda-forge
openjpeg                  2.4.0                hb52868f_1    conda-forge
openssl                   1.1.1t               h0b41bf4_0    conda-forge
packaging                 21.0               pyhd8ed1ab_0    conda-forge
pamela                    1.0.0                      py_0    conda-forge
pandas                    1.5.3                    pypi_0    pypi
pandoc                    2.14.0.3             h7f98852_0    conda-forge
pandocfilters             1.4.2                      py_1    conda-forge
pango                     1.48.7               hb8ff022_0    conda-forge
parso                     0.8.2              pyhd8ed1ab_0    conda-forge
partd                     1.2.0              pyhd8ed1ab_0    conda-forge
patsy                     0.5.1                      py_0    conda-forge
pcre                      8.45                 h9c3ff4c_0    conda-forge
pcre2                     10.37                h032f7d1_0    conda-forge
pexpect                   4.8.0              pyh9f0ad1d_2    conda-forge
pickleshare               0.7.5                   py_1003    conda-forge
pillow                    8.3.1            py39ha612740_0    conda-forge
pip                       21.1.3             pyhd8ed1ab_0    conda-forge
pixman                    0.40.0               h36c2ea0_0    conda-forge
platformdirs              3.5.1                    pypi_0    pypi
pluggy                    1.0.0                    pypi_0    pypi
pooch                     1.4.0              pyhd8ed1ab_0    conda-forge
prometheus_client         0.11.0             pyhd8ed1ab_0    conda-forge
prompt-toolkit            3.0.19             pyha770c72_0    conda-forge
protobuf                  3.17.2           py39he80948d_0    conda-forge
psutil                    5.8.0            py39h3811e60_1    conda-forge
pthread-stubs             0.4               h36c2ea0_1001    conda-forge
ptyprocess                0.7.0              pyhd3deb0d_0    conda-forge
pycosat                   0.6.3           py39h3811e60_1006    conda-forge
pycparser                 2.20               pyh9f0ad1d_2    conda-forge
pycurl                    7.43.0.6         py39h72e3413_1    conda-forge
pygments                  2.9.0              pyhd8ed1ab_0    conda-forge
pyjwt                     2.1.0              pyhd8ed1ab_0    conda-forge
pyopenssl                 20.0.1             pyhd8ed1ab_0    conda-forge
pyparsing                 2.4.7              pyh9f0ad1d_0    conda-forge
pyrsistent                0.17.3           py39h3811e60_2    conda-forge
pysocks                   1.7.1            py39hf3d152e_3    conda-forge
pytables                  3.6.1            py39hf6dc253_3    conda-forge
pytest                    7.3.1                    pypi_0    pypi
python                    3.9.5           h49503c6_0_cpython    conda-forge
python-dateutil           2.8.2              pyhd8ed1ab_0    conda-forge
python-editor             1.0.4                      py_0    conda-forge
python-json-logger        2.0.7                    pypi_0    pypi
python_abi                3.9                      2_cp39    conda-forge
pytz                      2021.1             pyhd8ed1ab_0    conda-forge
pywavelets                1.1.1            py39hce5d2b2_3    conda-forge
pyyaml                    5.4.1            py39h3811e60_0    conda-forge
pyzmq                     25.0.2                   pypi_0    pypi
r-askpass                 1.1               r41hcfec24a_2    conda-forge
r-assertthat              0.2.1             r41hc72bb7e_2    conda-forge
r-backports               1.2.1             r41hcfec24a_0    conda-forge
r-base                    4.1.0                hb67fd72_2    conda-forge
r-base64enc               0.1_3           r41hcfec24a_1004    conda-forge
r-bit                     4.0.4             r41hcfec24a_0    conda-forge
r-bit64                   4.0.5             r41hcfec24a_0    conda-forge
r-bitops                  1.0_7             r41hcfec24a_0    conda-forge
r-blob                    1.2.2             r41hc72bb7e_0    conda-forge
r-brew                    1.0_6           r41hc72bb7e_1003    conda-forge
r-brio                    1.1.2             r41hcfec24a_0    conda-forge
r-broom                   0.7.8             r41hc72bb7e_0    conda-forge
r-bslib                   0.2.5.1           r41hc72bb7e_0    conda-forge
r-cachem                  1.0.5             r41hcfec24a_0    conda-forge
r-callr                   3.7.0             r41hc72bb7e_0    conda-forge
r-caret                   6.0_88            r41hcfec24a_0    conda-forge
r-cellranger              1.1.0           r41hc72bb7e_1003    conda-forge
r-class                   7.3_19            r41hcfec24a_0    conda-forge
r-cli                     3.0.1             r41hc72bb7e_0    conda-forge
r-clipr                   0.7.1             r41hc72bb7e_0    conda-forge
r-codetools               0.2_18            r41hc72bb7e_0    conda-forge
r-colorspace              2.0_2             r41hcfec24a_0    conda-forge
r-commonmark              1.7             r41hcfec24a_1002    conda-forge
r-conflicted              1.0.4             r41hc72bb7e_2    conda-forge
r-covr                    3.5.1             r41h03ef668_0    conda-forge
r-cpp11                   0.3.1             r41hc72bb7e_0    conda-forge
r-crayon                  1.4.1             r41hc72bb7e_0    conda-forge
r-credentials             1.3.1             r41hc72bb7e_0    conda-forge
r-crosstalk               1.1.1             r41hc72bb7e_0    conda-forge
r-curl                    4.3.2             r41hcfec24a_0    conda-forge
r-data.table              1.14.0            r41hcfec24a_0    conda-forge
r-dbi                     1.1.1             r41hc72bb7e_0    conda-forge
r-dbplyr                  2.1.1             r41hc72bb7e_0    conda-forge
r-desc                    1.3.0             r41hc72bb7e_0    conda-forge
r-devtools                2.4.2             r41hc72bb7e_0    conda-forge
r-dials                   0.0.9             r41hc72bb7e_0    conda-forge
r-dicedesign              1.9               r41hcfec24a_0    conda-forge
r-diffobj                 0.3.4             r41hcfec24a_0    conda-forge
r-digest                  0.6.27            r41h03ef668_0    conda-forge
r-dplyr                   1.0.7             r41h03ef668_0    conda-forge
r-dt                      0.18              r41hc72bb7e_0    conda-forge
r-dtplyr                  1.1.0             r41hc72bb7e_0    conda-forge
r-ellipsis                0.3.2             r41hcfec24a_0    conda-forge
r-evaluate                0.14              r41hc72bb7e_2    conda-forge
r-fansi                   0.4.2             r41hcfec24a_0    conda-forge
r-farver                  2.1.0             r41h03ef668_0    conda-forge
r-fastmap                 1.1.0             r41h03ef668_0    conda-forge
r-forcats                 0.5.1             r41hc72bb7e_0    conda-forge
r-foreach                 1.5.1             r41hc72bb7e_0    conda-forge
r-forecast                8.15              r41h6dc32e9_0    conda-forge
r-fracdiff                1.5_1             r41hbfbffee_1    conda-forge
r-fs                      1.5.0             r41h03ef668_0    conda-forge
r-furrr                   0.2.3             r41hc72bb7e_0    conda-forge
r-future                  1.21.0            r41hc72bb7e_0    conda-forge
r-gargle                  1.2.0             r41hc72bb7e_0    conda-forge
r-generics                0.1.0             r41hc72bb7e_0    conda-forge
r-gert                    1.3.1             r41hbd84cd2_0    conda-forge
r-ggplot2                 3.3.5             r41hc72bb7e_0    conda-forge
r-gh                      1.3.0             r41hc72bb7e_0    conda-forge
r-git2r                   0.28.0            r41hf628c3e_0    conda-forge
r-gitcreds                0.1.1             r41hc72bb7e_0    conda-forge
r-globals                 0.14.0            r41hc72bb7e_0    conda-forge
r-glue                    1.4.2             r41hcfec24a_0    conda-forge
r-googledrive             2.0.0             r41hc72bb7e_0    conda-forge
r-googlesheets4           0.3.0             r41hc72bb7e_0    conda-forge
r-gower                   0.2.2             r41hcfec24a_0    conda-forge
r-gpfit                   1.0_8             r41hc72bb7e_1    conda-forge
r-gtable                  0.3.0             r41hc72bb7e_3    conda-forge
r-hardhat                 0.1.6             r41hc72bb7e_0    conda-forge
r-haven                   2.4.1             r41h2713e49_0    conda-forge
r-hexbin                  1.28.2            r41h859d828_0    conda-forge
r-highr                   0.9               r41hc72bb7e_0    conda-forge
r-hms                     1.1.0             r41hc72bb7e_0    conda-forge
r-htmltools               0.5.1.1           r41h03ef668_0    conda-forge
r-htmlwidgets             1.5.3             r41hc72bb7e_0    conda-forge
r-httpuv                  1.6.1             r41h03ef668_0    conda-forge
r-httr                    1.4.2             r41hc72bb7e_0    conda-forge
r-ids                     1.0.1             r41hc72bb7e_1    conda-forge
r-infer                   0.5.4             r41hc72bb7e_0    conda-forge
r-ini                     0.3.1           r41hc72bb7e_1003    conda-forge
r-ipred                   0.9_11            r41hcfec24a_0    conda-forge
r-irdisplay               1.0               r41hd8ed1ab_0    conda-forge
r-irkernel                1.2               r41hc72bb7e_0    conda-forge
r-isoband                 0.2.5             r41h03ef668_0    conda-forge
r-iterators               1.0.13            r41hc72bb7e_0    conda-forge
r-jquerylib               0.1.4             r41hc72bb7e_0    conda-forge
r-jsonlite                1.7.2             r41hcfec24a_0    conda-forge
r-kernsmooth              2.23_20           r41h742201e_0    conda-forge
r-knitr                   1.33              r41hc72bb7e_0    conda-forge
r-labeling                0.4.2             r41hc72bb7e_0    conda-forge
r-later                   1.2.0             r41h03ef668_0    conda-forge
r-lattice                 0.20_44           r41hcfec24a_0    conda-forge
r-lava                    1.6.9             r41hc72bb7e_0    conda-forge
r-lazyeval                0.2.2             r41hcfec24a_2    conda-forge
r-lhs                     1.1.1             r41h03ef668_0    conda-forge
r-lifecycle               1.0.0             r41hc72bb7e_0    conda-forge
r-listenv                 0.8.0             r41hc72bb7e_1    conda-forge
r-lmtest                  0.9_38            r41h859d828_1    conda-forge
r-lubridate               1.7.10            r41h03ef668_0    conda-forge
r-magrittr                2.0.1             r41hcfec24a_1    conda-forge
r-markdown                1.1               r41hcfec24a_1    conda-forge
r-mass                    7.3_54            r41hcfec24a_0    conda-forge
r-matrix                  1.3_4             r41he454529_0    conda-forge
r-memoise                 2.0.0             r41hc72bb7e_0    conda-forge
r-mgcv                    1.8_36            r41he454529_0    conda-forge
r-mime                    0.11              r41hcfec24a_0    conda-forge
r-modeldata               0.1.1             r41hc72bb7e_0    conda-forge
r-modelmetrics            1.2.2.2           r41h03ef668_1    conda-forge
r-modelr                  0.1.8             r41hc72bb7e_0    conda-forge
r-munsell                 0.5.0           r41hc72bb7e_1003    conda-forge
r-nlme                    3.1_152           r41h859d828_0    conda-forge
r-nnet                    7.3_16            r41hcfec24a_0    conda-forge
r-numderiv                2016.8_1.1        r41hc72bb7e_3    conda-forge
r-nycflights13            1.0.2             r41hc72bb7e_0    conda-forge
r-openssl                 1.4.4             r41he36bf35_0    conda-forge
r-parallelly              1.27.0            r41hc72bb7e_0    conda-forge
r-parsnip                 0.1.7             r41hc72bb7e_0    conda-forge
r-pbdzmq                  0.3_5             r41h42bf92c_1    conda-forge
r-pillar                  1.6.1             r41hc72bb7e_0    conda-forge
r-pkgbuild                1.2.0             r41hc72bb7e_0    conda-forge
r-pkgconfig               2.0.3             r41hc72bb7e_1    conda-forge
r-pkgload                 1.2.1             r41h03ef668_0    conda-forge
r-plogr                   0.2.0           r41hc72bb7e_1003    conda-forge
r-plyr                    1.8.6             r41h03ef668_1    conda-forge
r-praise                  1.0.0           r41hc72bb7e_1004    conda-forge
r-prettyunits             1.1.1             r41hc72bb7e_1    conda-forge
r-proc                    1.17.0.1          r41h03ef668_0    conda-forge
r-processx                3.5.2             r41hcfec24a_0    conda-forge
r-prodlim                 2019.11.13        r41h03ef668_1    conda-forge
r-progress                1.2.2             r41hc72bb7e_2    conda-forge
r-promises                1.2.0.1           r41h03ef668_0    conda-forge
r-ps                      1.6.0             r41hcfec24a_0    conda-forge
r-purrr                   0.3.4             r41hcfec24a_1    conda-forge
r-quadprog                1.5_8             r41h742201e_3    conda-forge
r-quantmod                0.4.18            r41hc72bb7e_0    conda-forge
r-r6                      2.5.0             r41hc72bb7e_0    conda-forge
r-randomforest            4.6_14          r41h859d828_1004    conda-forge
r-rappdirs                0.3.3             r41hcfec24a_0    conda-forge
r-rcmdcheck               1.3.3             r41hc72bb7e_3    conda-forge
r-rcolorbrewer            1.1_2           r41h785f33e_1003    conda-forge
r-rcpp                    1.0.7             r41h03ef668_0    conda-forge
r-rcpparmadillo           0.10.6.0.0        r41h306847c_0    conda-forge
r-rcurl                   1.98_1.3          r41hcfec24a_0    conda-forge
r-readr                   1.4.0             r41h03ef668_0    conda-forge
r-readxl                  1.3.1             r41h2713e49_4    conda-forge
r-recipes                 0.1.16            r41hc72bb7e_0    conda-forge
r-rematch                 1.0.1           r41hc72bb7e_1003    conda-forge
r-rematch2                2.1.2             r41hc72bb7e_1    conda-forge
r-remotes                 2.4.0             r41hc72bb7e_0    conda-forge
r-repr                    1.1.3             r41h785f33e_0    conda-forge
r-reprex                  2.0.0             r41hc72bb7e_0    conda-forge
r-reshape2                1.4.4             r41h03ef668_1    conda-forge
r-rex                     1.2.0             r41hc72bb7e_1    conda-forge
r-rlang                   0.4.11            r41hcfec24a_0    conda-forge
r-rmarkdown               2.9               r41hc72bb7e_1    conda-forge
r-rodbc                   1.3_17            r41hcfec24a_0    conda-forge
r-roxygen2                7.1.1             r41h03ef668_0    conda-forge
r-rpart                   4.1_15            r41hcfec24a_2    conda-forge
r-rprojroot               2.0.2             r41hc72bb7e_0    conda-forge
r-rsample                 0.1.0             r41hc72bb7e_0    conda-forge
r-rsqlite                 2.2.5             r41h03ef668_0    conda-forge
r-rstudioapi              0.13              r41hc72bb7e_0    conda-forge
r-rversions               2.1.1             r41hc72bb7e_0    conda-forge
r-rvest                   1.0.0             r41hc72bb7e_0    conda-forge
r-sass                    0.4.0             r41h03ef668_0    conda-forge
r-scales                  1.1.1             r41hc72bb7e_0    conda-forge
r-selectr                 0.4_2             r41hc72bb7e_1    conda-forge
r-sessioninfo             1.1.1           r41hc72bb7e_1002    conda-forge
r-shiny                   1.6.0             r41hc72bb7e_0    conda-forge
r-slider                  0.2.2             r41hcfec24a_0    conda-forge
r-sourcetools             0.1.7           r41h9c3ff4c_1002    conda-forge
r-squarem                 2021.1            r41hc72bb7e_0    conda-forge
r-stringi                 1.7.3             r41hcabe038_0    conda-forge
r-stringr                 1.4.0             r41hc72bb7e_2    conda-forge
r-survival                3.2_11            r41hcfec24a_0    conda-forge
r-sys                     3.4               r41hcfec24a_0    conda-forge
r-testthat                3.0.4             r41h03ef668_0    conda-forge
r-tibble                  3.1.3             r41hcfec24a_0    conda-forge
r-tidymodels              0.1.3             r41hc72bb7e_0    conda-forge
r-tidyr                   1.1.3             r41h03ef668_0    conda-forge
r-tidyselect              1.1.1             r41hc72bb7e_0    conda-forge
r-tidyverse               1.3.1             r41hc72bb7e_0    conda-forge
r-timedate                3043.102        r41hc72bb7e_1002    conda-forge
r-tinytex                 0.32              r41hc72bb7e_0    conda-forge
r-tseries                 0.10_48           r41h742201e_0    conda-forge
r-ttr                     0.24.2            r41hcfec24a_0    conda-forge
r-tune                    0.1.6             r41hc72bb7e_0    conda-forge
r-urca                    1.3_0           r41h859d828_1006    conda-forge
r-usethis                 2.0.1             r41hc72bb7e_0    conda-forge
r-utf8                    1.2.2             r41hcfec24a_0    conda-forge
r-uuid                    0.1_4             r41hcfec24a_1    conda-forge
r-vctrs                   0.3.8             r41hcfec24a_1    conda-forge
r-viridislite             0.4.0             r41hc72bb7e_0    conda-forge
r-waldo                   0.2.5             r41hc72bb7e_0    conda-forge
r-warp                    0.2.0             r41hcfec24a_1    conda-forge
r-whisker                 0.4               r41hc72bb7e_1    conda-forge
r-withr                   2.4.2             r41hc72bb7e_0    conda-forge
r-workflows               0.2.3             r41hc72bb7e_0    conda-forge
r-workflowsets            0.1.0             r41hc72bb7e_0    conda-forge
r-xfun                    0.24              r41h03ef668_0    conda-forge
r-xml2                    1.3.2             r41h03ef668_1    conda-forge
r-xopen                   1.0.0           r41hc72bb7e_1003    conda-forge
r-xtable                  1.8_4             r41hc72bb7e_3    conda-forge
r-xts                     0.12.1            r41hcfec24a_0    conda-forge
r-yaml                    2.2.1             r41hcfec24a_1    conda-forge
r-yardstick               0.0.8             r41h03ef668_0    conda-forge
r-zip                     2.2.0             r41hcfec24a_0    conda-forge
r-zoo                     1.8_9             r41hcfec24a_1    conda-forge
rapidfuzz                 3.0.0                    pypi_0    pypi
readline                  8.1                  h46c0cb4_0    conda-forge
regex                     2023.5.5                 pypi_0    pypi
reproc                    14.2.1               h36c2ea0_0    conda-forge
reproc-cpp                14.2.1               h58526e2_0    conda-forge
requests                  2.26.0             pyhd8ed1ab_0    conda-forge
requests-unixsocket       0.2.0                      py_0    conda-forge
rfc3339-validator         0.1.4                    pypi_0    pypi
rfc3986-validator         0.1.1                    pypi_0    pypi
rise                      5.7.1            py39hf3d152e_2    conda-forge
rpy2                      3.4.5           py39r41hce5d2b2_0    conda-forge
ruamel.yaml               0.17.10          py39h3811e60_0    conda-forge
ruamel.yaml.clib          0.2.2            py39h3811e60_2    conda-forge
ruamel_yaml               0.15.80         py39h3811e60_1004    conda-forge
scikit-image              0.18.2           py39hde0f152_0    conda-forge
scikit-learn              0.24.2           py39h4dfa638_0    conda-forge
scipy                     1.7.0            py39hee8e79c_1    conda-forge
seaborn                   0.11.1               hd8ed1ab_1    conda-forge
seaborn-base              0.11.1             pyhd8ed1ab_1    conda-forge
sed                       4.8                  he412f7d_0    conda-forge
send2trash                1.7.1              pyhd8ed1ab_0    conda-forge
setuptools                49.6.0           py39hf3d152e_3    conda-forge
simplegeneric             0.8.1                      py_1    conda-forge
six                       1.16.0             pyh6c4a22f_0    conda-forge
smmap                     5.0.0                    pypi_0    pypi
snappy                    1.1.8                he1b5a44_3    conda-forge
sniffio                   1.2.0            py39hf3d152e_1    conda-forge
sortedcontainers          2.4.0              pyhd8ed1ab_0    conda-forge
soupsieve                 2.0.1                      py_1    conda-forge
sqlalchemy                1.4.22           py39h3811e60_0    conda-forge
sqlite                    3.36.0               h9cd32fc_0    conda-forge
statsmodels               0.12.2           py39hce5d2b2_0    conda-forge
sympy                     1.8              py39hf3d152e_0    conda-forge
sysroot_linux-64          2.12                he073ed8_14    conda-forge
tblib                     1.7.0              pyhd8ed1ab_0    conda-forge
terminado                 0.10.1           py39hf3d152e_0    conda-forge
testpath                  0.5.0              pyhd8ed1ab_0    conda-forge
threadpoolctl             2.2.0              pyh8a188c0_0    conda-forge
tifffile                  2021.7.2           pyhd8ed1ab_0    conda-forge
timeout-decorator         0.5.0                    pypi_0    pypi
tinycss2                  1.2.1                    pypi_0    pypi
tk                        8.6.10               h21135ba_1    conda-forge
tktable                   2.10                 hb7b940f_3    conda-forge
tomli                     2.0.1                    pypi_0    pypi
toolz                     0.11.1                     py_0    conda-forge
tornado                   6.3.1                    pypi_0    pypi
tqdm                      4.61.2             pyhd8ed1ab_1    conda-forge
traitlets                 5.1.1                    pypi_0    pypi
typing-extensions         4.5.0                    pypi_0    pypi
tzdata                    2021a                he74cb21_1    conda-forge
tzlocal                   2.1                pyh9f0ad1d_0    conda-forge
unixodbc                  2.3.9                hb166930_0    conda-forge
urllib3                   1.26.6             pyhd8ed1ab_0    conda-forge
wcwidth                   0.2.5              pyh9f0ad1d_2    conda-forge
webencodings              0.5.1                      py_1    conda-forge
websocket-client          0.57.0           py39hf3d152e_4    conda-forge
wheel                     0.36.2             pyhd3deb0d_0    conda-forge
widgetsnbextension        3.5.1            py39hf3d152e_4    conda-forge
xlrd                      2.0.1              pyhd8ed1ab_3    conda-forge
xorg-kbproto              1.0.7             h7f98852_1002    conda-forge
xorg-libice               1.0.10               h7f98852_0    conda-forge
xorg-libsm                1.2.3             hd9c2040_1000    conda-forge
xorg-libx11               1.7.2                h7f98852_0    conda-forge
xorg-libxau               1.0.9                h7f98852_0    conda-forge
xorg-libxdmcp             1.1.3                h7f98852_0    conda-forge
xorg-libxext              1.3.4                h7f98852_1    conda-forge
xorg-libxrender           0.9.10            h7f98852_1003    conda-forge
xorg-libxt                1.2.1                h7f98852_2    conda-forge
xorg-renderproto          0.11.1            h7f98852_1002    conda-forge
xorg-xextproto            7.3.0             h7f98852_1002    conda-forge
xorg-xproto               7.0.31            h7f98852_1007    conda-forge
xz                        5.2.5                h516909a_1    conda-forge
yaml                      0.2.5                h516909a_0    conda-forge
zeromq                    4.3.4                h9c3ff4c_0    conda-forge
zfp                       0.5.5                h9c3ff4c_5    conda-forge
zict                      2.0.0                      py_0    conda-forge
zipp                      3.5.0              pyhd8ed1ab_0    conda-forge
zlib                      1.2.11            h516909a_1010    conda-forge
zstd                      1.5.0                ha95c52a_0    conda-forge
```
</details>




## System Packages

<details>
<summary>Details</summary>

```

WARNING: apt does not have a stable CLI interface. Use with caution in scripts.

Listing...
adduser/now 3.118ubuntu2 all [installed,local]
adwaita-icon-theme/now 3.36.1-2ubuntu0.20.04.2 all [installed,local]
apt-utils/now 2.0.9 amd64 [installed,local]
apt/now 2.0.9 amd64 [installed,local]
base-files/now 11ubuntu5.3 amd64 [installed,local]
base-passwd/now 3.5.47 amd64 [installed,local]
bash/now 5.0-6ubuntu1.1 amd64 [installed,local]
binutils-common/now 2.34-6ubuntu1.1 amd64 [installed,local]
binutils-x86-64-linux-gnu/now 2.34-6ubuntu1.1 amd64 [installed,local]
binutils/now 2.34-6ubuntu1.1 amd64 [installed,local]
bsdutils/now 1:2.34-0.1ubuntu9.1 amd64 [installed,local]
bzip2/now 1.0.8-2 amd64 [installed,local]
ca-certificates/now 20210119~20.04.1 all [installed,local]
cm-super-minimal/now 0.3.4-15 all [installed,local]
cm-super/now 0.3.4-15 all [installed,local]
cmake-data/now 3.16.3-1ubuntu1.20.04.1 all [installed,local]
cmake/now 3.16.3-1ubuntu1.20.04.1 amd64 [installed,local]
code-server/now 4.12.0 amd64 [installed,local]
coreutils/now 8.30-3ubuntu2 amd64 [installed,local]
cpp-9/now 9.3.0-17ubuntu1~20.04 amd64 [installed,local]
cpp/now 4:9.3.0-1ubuntu2 amd64 [installed,local]
curl/now 7.68.0-1ubuntu2.18 amd64 [installed,local]
dash/now 0.5.10.2-6 amd64 [installed,local]
debconf/now 1.5.73 all [installed,local]
debianutils/now 4.9.1 amd64 [installed,local]
dictionaries-common/now 1.28.1 all [installed,local]
diffutils/now 1:3.7-3 amd64 [installed,local]
dirmngr/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
dpkg/now 1.19.7ubuntu3 amd64 [installed,local]
dvipng/now 1.15-1.1 amd64 [installed,local]
e2fsprogs/now 1.45.5-2ubuntu1 amd64 [installed,local]
emacsen-common/now 3.0.4 all [installed,local]
fdisk/now 2.34-0.1ubuntu9.1 amd64 [installed,local]
ffmpeg/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
findutils/now 4.7.0-1ubuntu1 amd64 [installed,local]
fontconfig-config/now 2.13.1-2ubuntu3 all [installed,local]
fontconfig/now 2.13.1-2ubuntu3 amd64 [installed,local]
fonts-dejavu-core/now 2.37-1 all [installed,local]
fonts-dejavu-extra/now 2.37-1 all [installed,local]
fonts-dejavu/now 2.37-1 all [installed,local]
fonts-liberation/now 1:1.07.4-11 all [installed,local]
fonts-lmodern/now 2.004.5-6 all [installed,local]
fonts-urw-base35/now 20170801.1-3 all [installed,local]
gcc-10-base/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
gcc-9-base/now 9.3.0-17ubuntu1~20.04 amd64 [installed,local]
gcc-9/now 9.3.0-17ubuntu1~20.04 amd64 [installed,local]
gcc/now 4:9.3.0-1ubuntu2 amd64 [installed,local]
gfortran-9/now 9.3.0-17ubuntu1~20.04 amd64 [installed,local]
gfortran/now 4:9.3.0-1ubuntu2 amd64 [installed,local]
ghostscript/now 9.50~dfsg-5ubuntu4.2 amd64 [installed,local]
git-man/now 1:2.25.1-1ubuntu3.1 all [installed,local]
git/now 1:2.25.1-1ubuntu3.11 amd64 [installed,local]
gnupg-l10n/now 2.2.19-3ubuntu2.2 all [installed,local]
gnupg-utils/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
gnupg/now 2.2.19-3ubuntu2.2 all [installed,local]
gpg-agent/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
gpg-wks-client/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
gpg-wks-server/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
gpg/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
gpgconf/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
gpgsm/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
gpgv/now 2.2.19-3ubuntu2.2 amd64 [installed,local]
grep/now 3.4-1 amd64 [installed,local]
gtk-update-icon-cache/now 3.24.20-0ubuntu1 amd64 [installed,local]
gzip/now 1.10-0ubuntu4 amd64 [installed,local]
hicolor-icon-theme/now 0.17-2 all [installed,local]
hostname/now 3.23 amd64 [installed,local]
htop/now 2.2.0-2build1 amd64 [installed,local]
humanity-icon-theme/now 0.6.15 all [installed,local]
hunspell-en-us/now 1:2018.04.16-1 all [installed,local]
imagemagick-6-common/now 8:6.9.10.23+dfsg-2.1ubuntu11.4 all [installed,local]
init-system-helpers/now 1.57 all [installed,local]
inkscape/now 0.92.5-1ubuntu1.1 amd64 [installed,local]
jq/now 1.6-1ubuntu0.20.04.1 amd64 [installed,local]
less/now 551-1ubuntu0.1 amd64 [installed,local]
libacl1/now 2.2.53-6 amd64 [installed,local]
libaom0/now 1.0.0.errata1-3build1 amd64 [installed,local]
libapache-pom-java/now 18-1 all [installed,local]
libapparmor1/now 2.13.3-7ubuntu5.1 amd64 [installed,local]
libapt-pkg6.0/now 2.0.9 amd64 [installed,local]
libarchive13/now 3.4.0-2ubuntu1.2 amd64 [installed,local]
libasan5/now 9.3.0-17ubuntu1~20.04 amd64 [installed,local]
libasn1-8-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
libasound2-data/now 1.2.2-2.1ubuntu2.4 all [installed,local]
libasound2/now 1.2.2-2.1ubuntu2.4 amd64 [installed,local]
libaspell15/now 0.60.8-1build1 amd64 [installed,local]
libass9/now 1:0.14.0-2 amd64 [installed,local]
libassuan0/now 2.5.3-7ubuntu2 amd64 [installed,local]
libasyncns0/now 0.8-6 amd64 [installed,local]
libatk1.0-0/now 2.35.1-1ubuntu2 amd64 [installed,local]
libatk1.0-data/now 2.35.1-1ubuntu2 all [installed,local]
libatkmm-1.6-1v5/now 2.28.0-2build1 amd64 [installed,local]
libatomic1/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libattr1/now 1:2.4.48-5 amd64 [installed,local]
libaudit-common/now 1:2.8.5-2ubuntu6 all [installed,local]
libaudit1/now 1:2.8.5-2ubuntu6 amd64 [installed,local]
libavahi-client3/now 0.7-4ubuntu7.1 amd64 [installed,local]
libavahi-common-data/now 0.7-4ubuntu7.1 amd64 [installed,local]
libavahi-common3/now 0.7-4ubuntu7.1 amd64 [installed,local]
libavc1394-0/now 0.5.4-5 amd64 [installed,local]
libavcodec58/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libavdevice58/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libavfilter7/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libavformat58/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libavresample4/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libavutil56/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libbinutils/now 2.34-6ubuntu1.1 amd64 [installed,local]
libblkid1/now 2.34-0.1ubuntu9.1 amd64 [installed,local]
libbluray2/now 1:1.2.0-1 amd64 [installed,local]
libbrotli1/now 1.0.7-6ubuntu0.1 amd64 [installed,local]
libbs2b0/now 3.1.0+dfsg-2.2build1 amd64 [installed,local]
libbsd0/now 0.10.0-1 amd64 [installed,local]
libbz2-1.0/now 1.0.8-2 amd64 [installed,local]
libc-bin/now 2.31-0ubuntu9.2 amd64 [installed,local]
libc-dev-bin/now 2.31-0ubuntu9.2 amd64 [installed,local]
libc6-dev/now 2.31-0ubuntu9.2 amd64 [installed,local]
libc6/now 2.31-0ubuntu9.2 amd64 [installed,local]
libcaca0/now 0.99.beta19-2.1ubuntu1.20.04.1 amd64 [installed,local]
libcairo-gobject2/now 1.16.0-4ubuntu1 amd64 [installed,local]
libcairo2/now 1.16.0-4ubuntu1 amd64 [installed,local]
libcairomm-1.0-1v5/now 1.12.2-4build1 amd64 [installed,local]
libcanberra0/now 0.30-7ubuntu1 amd64 [installed,local]
libcap-ng0/now 0.7.9-2.1build1 amd64 [installed,local]
libcbor0.6/now 0.6.0-0ubuntu1 amd64 [installed,local]
libcc1-0/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libcdio-cdda2/now 10.2+2.0.0-1 amd64 [installed,local]
libcdio-paranoia2/now 10.2+2.0.0-1 amd64 [installed,local]
libcdio18/now 2.0.0-2 amd64 [installed,local]
libcdr-0.1-1/now 0.1.6-1build2 amd64 [installed,local]
libchromaprint1/now 1.4.3-3build1 amd64 [installed,local]
libcodec2-0.9/now 0.9.2-2 amd64 [installed,local]
libcom-err2/now 1.45.5-2ubuntu1 amd64 [installed,local]
libcommons-logging-java/now 1.2-2 all [installed,local]
libcommons-parent-java/now 43-1 all [installed,local]
libcrypt-dev/now 1:4.4.10-10ubuntu4 amd64 [installed,local]
libcrypt1/now 1:4.4.10-10ubuntu4 amd64 [installed,local]
libctf-nobfd0/now 2.34-6ubuntu1.1 amd64 [installed,local]
libctf0/now 2.34-6ubuntu1.1 amd64 [installed,local]
libcups2/now 2.3.1-9ubuntu1.1 amd64 [installed,local]
libcurl3-gnutls/now 7.68.0-1ubuntu2.5 amd64 [installed,local]
libcurl4/now 7.68.0-1ubuntu2.18 amd64 [installed,local]
libdatrie1/now 0.2.12-3 amd64 [installed,local]
libdb5.3/now 5.3.28+dfsg1-0.6ubuntu2 amd64 [installed,local]
libdbus-1-3/now 1.12.16-2ubuntu2.1 amd64 [installed,local]
libdbus-glib-1-2/now 0.110-5fakssync1 amd64 [installed,local]
libdc1394-22/now 2.2.5-2.1 amd64 [installed,local]
libdebconfclient0/now 0.251ubuntu1 amd64 [installed,local]
libdrm-amdgpu1/now 2.4.102-1ubuntu1~20.04.1 amd64 [installed,local]
libdrm-common/now 2.4.102-1ubuntu1~20.04.1 all [installed,local]
libdrm-intel1/now 2.4.102-1ubuntu1~20.04.1 amd64 [installed,local]
libdrm-nouveau2/now 2.4.102-1ubuntu1~20.04.1 amd64 [installed,local]
libdrm-radeon1/now 2.4.102-1ubuntu1~20.04.1 amd64 [installed,local]
libdrm2/now 2.4.102-1ubuntu1~20.04.1 amd64 [installed,local]
libedit2/now 3.1-20191231-1 amd64 [installed,local]
libelf1/now 0.176-1.1build1 amd64 [installed,local]
libenchant-2-2/now 2.2.8-1ubuntu0.20.04.1 amd64 [installed,local]
liberror-perl/now 0.17029-1 all [installed,local]
libevent-2.1-7/now 2.1.11-stable-1 amd64 [installed,local]
libexpat1/now 2.2.9-1build1 amd64 [installed,local]
libext2fs2/now 1.45.5-2ubuntu1 amd64 [installed,local]
libfdisk1/now 2.34-0.1ubuntu9.1 amd64 [installed,local]
libffi7/now 3.3-4 amd64 [installed,local]
libfftw3-double3/now 3.3.8-2ubuntu1 amd64 [installed,local]
libfido2-1/now 1.3.1-1ubuntu2 amd64 [installed,local]
libflac8/now 1.3.3-1build1 amd64 [installed,local]
libflite1/now 2.1-release-3 amd64 [installed,local]
libfontbox-java/now 1:1.8.16-2 all [installed,local]
libfontconfig1/now 2.13.1-2ubuntu3 amd64 [installed,local]
libfontenc1/now 1:1.1.4-0ubuntu1 amd64 [installed,local]
libfreetype6/now 2.10.1-2ubuntu0.1 amd64 [installed,local]
libfribidi0/now 1.0.8-2 amd64 [installed,local]
libgc1c2/now 1:7.6.4-0.4ubuntu1 amd64 [installed,local]
libgcc-9-dev/now 9.3.0-17ubuntu1~20.04 amd64 [installed,local]
libgcc-s1/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libgcrypt20/now 1.8.5-5ubuntu1 amd64 [installed,local]
libgd3/now 2.2.5-5.2ubuntu2 amd64 [installed,local]
libgdbm-compat4/now 1.18.1-5 amd64 [installed,local]
libgdbm6/now 1.18.1-5 amd64 [installed,local]
libgdk-pixbuf2.0-0/now 2.40.0+dfsg-3ubuntu0.2 amd64 [installed,local]
libgdk-pixbuf2.0-common/now 2.40.0+dfsg-3ubuntu0.2 all [installed,local]
libgfortran-9-dev/now 9.3.0-17ubuntu1~20.04 amd64 [installed,local]
libgfortran5/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libgl1-mesa-dri/now 20.2.6-0ubuntu0.20.04.1 amd64 [installed,local]
libgl1/now 1.3.2-1~ubuntu0.20.04.1 amd64 [installed,local]
libglapi-mesa/now 20.2.6-0ubuntu0.20.04.1 amd64 [installed,local]
libglib2.0-0/now 2.64.6-1~ubuntu20.04.3 amd64 [installed,local]
libglibmm-2.4-1v5/now 2.64.2-1 amd64 [installed,local]
libglvnd0/now 1.3.2-1~ubuntu0.20.04.1 amd64 [installed,local]
libglx-mesa0/now 20.2.6-0ubuntu0.20.04.1 amd64 [installed,local]
libglx0/now 1.3.2-1~ubuntu0.20.04.1 amd64 [installed,local]
libgme0/now 0.6.2-1build1 amd64 [installed,local]
libgmp10/now 2:6.2.0+dfsg-4 amd64 [installed,local]
libgnutls30/now 3.6.13-2ubuntu1.3 amd64 [installed,local]
libgomp1/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libgpg-error0/now 1.37-1 amd64 [installed,local]
libgpm2/now 1.20.7-5 amd64 [installed,local]
libgraphite2-3/now 1.3.13-11build1 amd64 [installed,local]
libgs9-common/now 9.50~dfsg-5ubuntu4.2 all [installed,local]
libgs9/now 9.50~dfsg-5ubuntu4.2 amd64 [installed,local]
libgsl23/now 2.5+dfsg-6build1 amd64 [installed,local]
libgslcblas0/now 2.5+dfsg-6build1 amd64 [installed,local]
libgsm1/now 1.0.18-2 amd64 [installed,local]
libgssapi-krb5-2/now 1.17-6ubuntu4.1 amd64 [installed,local]
libgssapi3-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
libgtk2.0-0/now 2.24.32-4ubuntu4 amd64 [installed,local]
libgtk2.0-common/now 2.24.32-4ubuntu4 all [installed,local]
libgtkmm-2.4-1v5/now 1:2.24.5-4ubuntu2 amd64 [installed,local]
libgtkspell0/now 2.0.16-1.3 amd64 [installed,local]
libharfbuzz-icu0/now 2.6.4-1ubuntu4 amd64 [installed,local]
libharfbuzz0b/now 2.6.4-1ubuntu4 amd64 [installed,local]
libhcrypto4-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
libheimbase1-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
libheimntlm0-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
libhogweed5/now 3.5.1+really3.5.1-2ubuntu0.1 amd64 [installed,local]
libhunspell-1.7-0/now 1.7.0-2build2 amd64 [installed,local]
libhx509-5-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
libice6/now 2:1.0.10-0ubuntu1 amd64 [installed,local]
libicu66/now 66.1-2ubuntu2 amd64 [installed,local]
libidn11/now 1.33-2.2ubuntu2 amd64 [installed,local]
libidn2-0/now 2.2.0-2 amd64 [installed,local]
libiec61883-0/now 1.2.0-3 amd64 [installed,local]
libijs-0.35/now 0.35-15 amd64 [installed,local]
libisl22/now 0.22.1-1 amd64 [installed,local]
libitm1/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libjack-jackd2-0/now 1.9.12~dfsg-2ubuntu2 amd64 [installed,local]
libjbig0/now 2.1-3.1build1 amd64 [installed,local]
libjbig2dec0/now 0.18-1ubuntu1 amd64 [installed,local]
libjpeg-turbo8/now 2.0.3-0ubuntu1.20.04.1 amd64 [installed,local]
libjpeg8/now 8c-2ubuntu8 amd64 [installed,local]
libjq1/now 1.6-1ubuntu0.20.04.1 amd64 [installed,local]
libjsoncpp1/now 1.7.4-3.1ubuntu2 amd64 [installed,local]
libk5crypto3/now 1.17-6ubuntu4.1 amd64 [installed,local]
libkeyutils1/now 1.6-6ubuntu1 amd64 [installed,local]
libkpathsea6/now 2019.20190605.51237-3build2 amd64 [installed,local]
libkrb5-26-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
libkrb5-3/now 1.17-6ubuntu4.1 amd64 [installed,local]
libkrb5support0/now 1.17-6ubuntu4.1 amd64 [installed,local]
libksba8/now 1.3.5-2ubuntu0.20.04.2 amd64 [installed,local]
liblcms2-2/now 2.9-4 amd64 [installed,local]
libldap-2.4-2/now 2.4.49+dfsg-2ubuntu1.8 amd64 [installed,local]
libldap-common/now 2.4.49+dfsg-2ubuntu1.8 all [installed,local]
liblilv-0-0/now 0.24.6-1ubuntu0.1 amd64 [installed,local]
libllvm11/now 1:11.0.0-2~ubuntu20.04.1 amd64 [installed,local]
liblqr-1-0/now 0.4.2-2.1 amd64 [installed,local]
liblsan0/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libltdl7/now 2.4.6-14 amd64 [installed,local]
liblz4-1/now 1.9.2-2ubuntu0.20.04.1 amd64 [installed,local]
liblzma5/now 5.2.4-1ubuntu1 amd64 [installed,local]
libmagick++-6.q16-8/now 8:6.9.10.23+dfsg-2.1ubuntu11.4 amd64 [installed,local]
libmagickcore-6.q16-6/now 8:6.9.10.23+dfsg-2.1ubuntu11.4 amd64 [installed,local]
libmagickwand-6.q16-6/now 8:6.9.10.23+dfsg-2.1ubuntu11.4 amd64 [installed,local]
libmount1/now 2.34-0.1ubuntu9.1 amd64 [installed,local]
libmp3lame0/now 3.100-3 amd64 [installed,local]
libmpc3/now 1.1.0-1 amd64 [installed,local]
libmpdec2/now 2.4.2-3 amd64 [installed,local]
libmpfr6/now 4.0.2-1 amd64 [installed,local]
libmpg123-0/now 1.25.13-1 amd64 [installed,local]
libmysofa1/now 1.0~dfsg0-1 amd64 [installed,local]
libncurses6/now 6.2-0ubuntu2 amd64 [installed,local]
libncursesw6/now 6.2-0ubuntu2 amd64 [installed,local]
libnettle7/now 3.5.1+really3.5.1-2ubuntu0.1 amd64 [installed,local]
libnghttp2-14/now 1.40.0-1build1 amd64 [installed,local]
libnorm1/now 1.5.8+dfsg2-2build1 amd64 [installed,local]
libnpth0/now 1.6-1 amd64 [installed,local]
libnspr4/now 2:4.25-1 amd64 [installed,local]
libnss3/now 2:3.49.1-1ubuntu1.5 amd64 [installed,local]
libnuma1/now 2.0.12-1 amd64 [installed,local]
libogg0/now 1.3.4-0ubuntu1 amd64 [installed,local]
libonig5/now 6.9.4-1 amd64 [installed,local]
libopenal-data/now 1:1.19.1-1 all [installed,local]
libopenal1/now 1:1.19.1-1 amd64 [installed,local]
libopenjp2-7/now 2.3.1-1ubuntu4.20.04.1 amd64 [installed,local]
libopenmpt0/now 0.4.11-1build1 amd64 [installed,local]
libopus0/now 1.3.1-0ubuntu1 amd64 [installed,local]
libp11-kit0/now 0.23.20-1ubuntu0.1 amd64 [installed,local]
libpam-modules-bin/now 1.3.1-5ubuntu4.2 amd64 [installed,local]
libpam-modules/now 1.3.1-5ubuntu4.2 amd64 [installed,local]
libpam-runtime/now 1.3.1-5ubuntu4.2 all [installed,local]
libpam0g/now 1.3.1-5ubuntu4.2 amd64 [installed,local]
libpango-1.0-0/now 1.44.7-2ubuntu4 amd64 [installed,local]
libpangocairo-1.0-0/now 1.44.7-2ubuntu4 amd64 [installed,local]
libpangoft2-1.0-0/now 1.44.7-2ubuntu4 amd64 [installed,local]
libpangomm-1.4-1v5/now 2.42.0-2build1 amd64 [installed,local]
libpaper-utils/now 1.1.28 amd64 [installed,local]
libpaper1/now 1.1.28 amd64 [installed,local]
libpciaccess0/now 0.16-0ubuntu1 amd64 [installed,local]
libpcre2-8-0/now 10.34-7 amd64 [installed,local]
libpcre3/now 2:8.39-12build1 amd64 [installed,local]
libpdfbox-java/now 1:1.8.16-2 all [installed,local]
libperl5.30/now 5.30.0-9ubuntu0.2 amd64 [installed,local]
libpgm-5.2-0/now 5.2.122~dfsg-3ubuntu1 amd64 [installed,local]
libpixman-1-0/now 0.38.4-0ubuntu1 amd64 [installed,local]
libpng16-16/now 1.6.37-2 amd64 [installed,local]
libpoppler-glib8/now 0.86.1-0ubuntu1 amd64 [installed,local]
libpoppler97/now 0.86.1-0ubuntu1 amd64 [installed,local]
libpopt0/now 1.16-14 amd64 [installed,local]
libpostproc55/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libpotrace0/now 1.16-2 amd64 [installed,local]
libprocps8/now 2:3.3.16-1ubuntu2.1 amd64 [installed,local]
libpsl5/now 0.21.0-1ubuntu1 amd64 [installed,local]
libptexenc1/now 2019.20190605.51237-3build2 amd64 [installed,local]
libpthread-stubs0-dev/now 0.4-1 amd64 [installed,local]
libpulse0/now 1:13.99.1-1ubuntu3.11 amd64 [installed,local]
libpython2-stdlib/now 2.7.17-2ubuntu4 amd64 [installed,local]
libpython2.7-minimal/now 2.7.18-1~20.04.1 amd64 [installed,local]
libpython2.7-stdlib/now 2.7.18-1~20.04.1 amd64 [installed,local]
libpython3-stdlib/now 3.8.2-0ubuntu2 amd64 [installed,local]
libpython3.8-minimal/now 3.8.10-0ubuntu1~20.04.7 amd64 [installed,local]
libpython3.8-stdlib/now 3.8.10-0ubuntu1~20.04.7 amd64 [installed,local]
libpython3.8/now 3.8.10-0ubuntu1~20.04.7 amd64 [installed,local]
libquadmath0/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libraw1394-11/now 2.1.2-1 amd64 [installed,local]
libreadline8/now 8.0-4 amd64 [installed,local]
librevenge-0.0-0/now 0.0.4-6ubuntu5 amd64 [installed,local]
librhash0/now 1.3.9-1 amd64 [installed,local]
libroken18-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
librsvg2-2/now 2.48.9-1ubuntu0.20.04.1 amd64 [installed,local]
librsvg2-common/now 2.48.9-1ubuntu0.20.04.1 amd64 [installed,local]
librtmp1/now 2.4+20151223.gitfa8646d.1-2build1 amd64 [installed,local]
librubberband2/now 1.8.2-1build1 amd64 [installed,local]
libsamplerate0/now 0.1.9-2 amd64 [installed,local]
libsasl2-2/now 2.1.27+dfsg-2 amd64 [installed,local]
libsasl2-modules-db/now 2.1.27+dfsg-2 amd64 [installed,local]
libsdl2-2.0-0/now 2.0.10+dfsg1-3 amd64 [installed,local]
libseccomp2/now 2.5.1-1ubuntu1~20.04.1 amd64 [installed,local]
libselinux1/now 3.0-1build2 amd64 [installed,local]
libsemanage-common/now 3.0-1build2 all [installed,local]
libsemanage1/now 3.0-1build2 amd64 [installed,local]
libsensors-config/now 1:3.6.0-2ubuntu1 all [installed,local]
libsensors5/now 1:3.6.0-2ubuntu1 amd64 [installed,local]
libsepol1/now 3.0-1 amd64 [installed,local]
libserd-0-0/now 0.30.2-1 amd64 [installed,local]
libshine3/now 3.1.1-2 amd64 [installed,local]
libsigc++-2.0-0v5/now 2.10.2-1build1 amd64 [installed,local]
libslang2/now 2.3.2-4 amd64 [installed,local]
libsm6/now 2:1.2.3-1 amd64 [installed,local]
libsmartcols1/now 2.34-0.1ubuntu9.1 amd64 [installed,local]
libsnappy1v5/now 1.1.8-1build1 amd64 [installed,local]
libsndfile1/now 1.0.28-7 amd64 [installed,local]
libsndio7.0/now 1.5.0-3 amd64 [installed,local]
libsodium23/now 1.0.18-1 amd64 [installed,local]
libsord-0-0/now 0.16.4-1 amd64 [installed,local]
libsoxr0/now 0.1.3-2build1 amd64 [installed,local]
libspeex1/now 1.2~rc1.2-1.1ubuntu1 amd64 [installed,local]
libsqlite3-0/now 3.31.1-4ubuntu0.2 amd64 [installed,local]
libsratom-0-0/now 0.6.4-1 amd64 [installed,local]
libss2/now 1.45.5-2ubuntu1 amd64 [installed,local]
libssh-4/now 0.9.3-2ubuntu2.1 amd64 [installed,local]
libssh-gcrypt-4/now 0.9.3-2ubuntu2.1 amd64 [installed,local]
libssl1.1/now 1.1.1f-1ubuntu2.4 amd64 [installed,local]
libstdc++6/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libswresample3/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libswscale5/now 7:4.2.4-1ubuntu0.1 amd64 [installed,local]
libsynctex2/now 2019.20190605.51237-3build2 amd64 [installed,local]
libsystemd0/now 245.4-4ubuntu3.6 amd64 [installed,local]
libtasn1-6/now 4.16.0-2 amd64 [installed,local]
libtdb1/now 1.4.5-0ubuntu0.20.04.1 amd64 [installed,local]
libteckit0/now 2.5.8+ds2-5ubuntu2 amd64 [installed,local]
libtexlua53/now 2019.20190605.51237-3build2 amd64 [installed,local]
libtexluajit2/now 2019.20190605.51237-3build2 amd64 [installed,local]
libtext-iconv-perl/now 1.7-7 amd64 [installed,local]
libthai-data/now 0.1.28-3 all [installed,local]
libthai0/now 0.1.28-3 amd64 [installed,local]
libtheora0/now 1.1.1+dfsg.1-15ubuntu2 amd64 [installed,local]
libtiff5/now 4.1.0+git191117-2ubuntu0.20.04.1 amd64 [installed,local]
libtinfo6/now 6.2-0ubuntu2 amd64 [installed,local]
libtsan0/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libtwolame0/now 0.4.0-2 amd64 [installed,local]
libubsan1/now 10.3.0-1ubuntu1~20.04 amd64 [installed,local]
libudev1/now 245.4-4ubuntu3.6 amd64 [installed,local]
libunistring2/now 0.9.10-2 amd64 [installed,local]
libusb-1.0-0/now 2:1.0.23-2build1 amd64 [installed,local]
libutempter0/now 1.1.6-4 amd64 [installed,local]
libuuid1/now 2.34-0.1ubuntu9.1 amd64 [installed,local]
libuv1/now 1.34.2-1ubuntu1.3 amd64 [installed,local]
libva-drm2/now 2.7.0-2 amd64 [installed,local]
libva-x11-2/now 2.7.0-2 amd64 [installed,local]
libva2/now 2.7.0-2 amd64 [installed,local]
libvdpau1/now 1.3-1ubuntu2 amd64 [installed,local]
libvidstab1.1/now 1.1.0-2 amd64 [installed,local]
libvisio-0.1-1/now 0.1.7-1build2 amd64 [installed,local]
libvorbis0a/now 1.3.6-2ubuntu1 amd64 [installed,local]
libvorbisenc2/now 1.3.6-2ubuntu1 amd64 [installed,local]
libvorbisfile3/now 1.3.6-2ubuntu1 amd64 [installed,local]
libvpx6/now 1.8.2-1build1 amd64 [installed,local]
libvulkan1/now 1.2.131.2-1 amd64 [installed,local]
libwavpack1/now 5.2.0-1ubuntu0.1 amd64 [installed,local]
libwayland-client0/now 1.18.0-1 amd64 [installed,local]
libwayland-cursor0/now 1.18.0-1 amd64 [installed,local]
libwayland-egl1/now 1.18.0-1 amd64 [installed,local]
libwebp6/now 0.6.1-2ubuntu0.20.04.1 amd64 [installed,local]
libwebpmux3/now 0.6.1-2ubuntu0.20.04.1 amd64 [installed,local]
libwind0-heimdal/now 7.7.0+dfsg-1ubuntu1 amd64 [installed,local]
libwpd-0.10-10/now 0.10.3-1build1 amd64 [installed,local]
libwpg-0.3-3/now 0.3.3-1build1 amd64 [installed,local]
libwrap0/now 7.6.q-30 amd64 [installed,local]
libx11-6/now 2:1.6.9-2ubuntu1.2 amd64 [installed,local]
libx11-data/now 2:1.6.9-2ubuntu1.2 all [installed,local]
libx11-dev/now 2:1.6.9-2ubuntu1.2 amd64 [installed,local]
libx11-xcb1/now 2:1.6.9-2ubuntu1.2 amd64 [installed,local]
libx264-155/now 2:0.155.2917+git0a84d98-2 amd64 [installed,local]
libx265-179/now 3.2.1-1build1 amd64 [installed,local]
libxau-dev/now 1:1.0.9-0ubuntu1 amd64 [installed,local]
libxau6/now 1:1.0.9-0ubuntu1 amd64 [installed,local]
libxaw7/now 2:1.0.13-1 amd64 [installed,local]
libxcb-dri2-0/now 1.14-2 amd64 [installed,local]
libxcb-dri3-0/now 1.14-2 amd64 [installed,local]
libxcb-glx0/now 1.14-2 amd64 [installed,local]
libxcb-present0/now 1.14-2 amd64 [installed,local]
libxcb-render0/now 1.14-2 amd64 [installed,local]
libxcb-shape0/now 1.14-2 amd64 [installed,local]
libxcb-shm0/now 1.14-2 amd64 [installed,local]
libxcb-sync1/now 1.14-2 amd64 [installed,local]
libxcb-xfixes0/now 1.14-2 amd64 [installed,local]
libxcb1-dev/now 1.14-2 amd64 [installed,local]
libxcb1/now 1.14-2 amd64 [installed,local]
libxcomposite1/now 1:0.4.5-1 amd64 [installed,local]
libxcursor1/now 1:1.2.0-2 amd64 [installed,local]
libxdamage1/now 1:1.1.5-2 amd64 [installed,local]
libxdmcp-dev/now 1:1.1.3-0ubuntu1 amd64 [installed,local]
libxdmcp6/now 1:1.1.3-0ubuntu1 amd64 [installed,local]
libxext-dev/now 2:1.3.4-0ubuntu1 amd64 [installed,local]
libxext6/now 2:1.3.4-0ubuntu1 amd64 [installed,local]
libxfixes3/now 1:5.0.3-2 amd64 [installed,local]
libxi6/now 2:1.7.10-0ubuntu1 amd64 [installed,local]
libxinerama1/now 2:1.1.4-2 amd64 [installed,local]
libxkbcommon0/now 0.10.0-1 amd64 [installed,local]
libxml2/now 2.9.10+dfsg-5ubuntu0.20.04.1 amd64 [installed,local]
libxmu6/now 2:1.1.3-0ubuntu1 amd64 [installed,local]
libxpm4/now 1:3.5.12-1 amd64 [installed,local]
libxrandr2/now 2:1.5.2-0ubuntu1 amd64 [installed,local]
libxrender1/now 1:0.9.10-1 amd64 [installed,local]
libxshmfence1/now 1.3-1 amd64 [installed,local]
libxslt1.1/now 1.1.34-4 amd64 [installed,local]
libxss1/now 1:1.2.3-1 amd64 [installed,local]
libxt6/now 1:1.1.5-1 amd64 [installed,local]
libxv1/now 2:1.0.11-1 amd64 [installed,local]
libxvidcore4/now 2:1.3.7-1 amd64 [installed,local]
libxxf86vm1/now 1:1.1.4-1build1 amd64 [installed,local]
libzmq5/now 4.3.2-2ubuntu1 amd64 [installed,local]
libzstd1/now 1.4.4+dfsg-3ubuntu0.1 amd64 [installed,local]
libzvbi-common/now 0.2.35-17 all [installed,local]
libzvbi0/now 0.2.35-17 amd64 [installed,local]
libzzip-0-13/now 0.13.62-3.2ubuntu1 amd64 [installed,local]
linux-libc-dev/now 5.4.0-80.90 amd64 [installed,local]
lmodern/now 2.004.5-6 all [installed,local]
locales/now 2.31-0ubuntu9.2 all [installed,local]
login/now 1:4.8.1-1ubuntu5.20.04 amd64 [installed,local]
logsave/now 1.45.5-2ubuntu1 amd64 [installed,local]
lsb-base/now 11.1.0ubuntu2 all [installed,local]
mawk/now 1.3.4.20200120-2 amd64 [installed,local]
mime-support/now 3.64ubuntu1 all [installed,local]
mount/now 2.34-0.1ubuntu9.1 amd64 [installed,local]
nano-tiny/now 4.8-1ubuntu1 amd64 [installed,local]
nano/now 4.8-1ubuntu1 amd64 [installed,local]
ncurses-base/now 6.2-0ubuntu2 all [installed,local]
ncurses-bin/now 6.2-0ubuntu2 amd64 [installed,local]
netcat-openbsd/now 1.206-1ubuntu1 amd64 [installed,local]
netcat/now 1.206-1ubuntu1 all [installed,local]
ocl-icd-libopencl1/now 2.2.11-1ubuntu1 amd64 [installed,local]
openssh-client/now 1:8.2p1-4ubuntu0.7 amd64 [installed,local]
openssh-server/now 1:8.2p1-4ubuntu0.7 amd64 [installed,local]
openssh-sftp-server/now 1:8.2p1-4ubuntu0.7 amd64 [installed,local]
openssl/now 1.1.1f-1ubuntu2.4 amd64 [installed,local]
p7zip-full/now 16.02+dfsg-7build1 amd64 [installed,local]
p7zip/now 16.02+dfsg-7build1 amd64 [installed,local]
passwd/now 1:4.8.1-1ubuntu5.20.04 amd64 [installed,local]
perl-base/now 5.30.0-9ubuntu0.2 amd64 [installed,local]
perl-modules-5.30/now 5.30.0-9ubuntu0.2 all [installed,local]
perl/now 5.30.0-9ubuntu0.2 amd64 [installed,local]
pfb2t1c2pfb/now 0.3-11 amd64 [installed,local]
pinentry-curses/now 1.1.0-3build1 amd64 [installed,local]
poppler-data/now 0.4.9-2 all [installed,local]
preview-latex-style/now 11.91-2ubuntu2 all [installed,local]
procps/now 2:3.3.16-1ubuntu2.1 amd64 [installed,local]
python2-minimal/now 2.7.17-2ubuntu4 amd64 [installed,local]
python2.7-minimal/now 2.7.18-1~20.04.1 amd64 [installed,local]
python2.7/now 2.7.18-1~20.04.1 amd64 [installed,local]
python2/now 2.7.17-2ubuntu4 amd64 [installed,local]
python3-minimal/now 3.8.2-0ubuntu2 amd64 [installed,local]
python3.8-minimal/now 3.8.10-0ubuntu1~20.04.7 amd64 [installed,local]
python3.8/now 3.8.10-0ubuntu1~20.04.7 amd64 [installed,local]
python3/now 3.8.2-0ubuntu2 amd64 [installed,local]
readline-common/now 8.0-4 all [installed,local]
rsync/now 3.1.3-8ubuntu0.5 amd64 [installed,local]
run-one/now 1.17-0ubuntu1 all [installed,local]
screen/now 4.8.0-1ubuntu0.1 amd64 [installed,local]
sed/now 4.7-1 amd64 [installed,local]
sensible-utils/now 0.0.12+nmu1 all [installed,local]
shared-mime-info/now 1.15-1 amd64 [installed,local]
sound-theme-freedesktop/now 0.8-2ubuntu1 all [installed,local]
sudo/now 1.8.31-1ubuntu1.2 amd64 [installed,local]
sysvinit-utils/now 2.96-2.1ubuntu1 amd64 [installed,local]
t1utils/now 1.41-3 amd64 [installed,local]
tar/now 1.30+dfsg-7ubuntu0.20.04.1 amd64 [installed,local]
teckit/now 2.5.8+ds2-5ubuntu2 amd64 [installed,local]
tex-common/now 6.13 all [installed,local]
texlive-base/now 2019.20200218-1 all [installed,local]
texlive-binaries/now 2019.20190605.51237-3build2 amd64 [installed,local]
texlive-fonts-recommended/now 2019.20200218-1 all [installed,local]
texlive-latex-base/now 2019.20200218-1 all [installed,local]
texlive-latex-extra/now 2019.202000218-1 all [installed,local]
texlive-latex-recommended/now 2019.20200218-1 all [installed,local]
texlive-pictures/now 2019.20200218-1 all [installed,local]
texlive-plain-generic/now 2019.202000218-1 all [installed,local]
texlive-xetex/now 2019.20200218-1 all [installed,local]
tini/now 0.18.0-1 amd64 [installed,local]
tipa/now 2:1.3-20 all [installed,local]
tmux/now 3.0a-2ubuntu0.4 amd64 [installed,local]
tzdata/now 2021a-0ubuntu0.20.04 all [installed,local]
ubuntu-keyring/now 2020.02.11.4 all [installed,local]
ubuntu-mono/now 19.04-0ubuntu3 all [installed,local]
ucf/now 3.0038+nmu1 all [installed,local]
unzip/now 6.0-25ubuntu1.1 amd64 [installed,local]
util-linux/now 2.34-0.1ubuntu9.1 amd64 [installed,local]
vim-common/now 2:8.1.2269-1ubuntu5.14 all [installed,local]
vim-runtime/now 2:8.1.2269-1ubuntu5.14 all [installed,local]
vim-tiny/now 2:8.1.2269-1ubuntu5.14 amd64 [installed,local]
vim/now 2:8.1.2269-1ubuntu5.14 amd64 [installed,local]
wget/now 1.20.3-1ubuntu2 amd64 [installed,local]
x11-common/now 1:7.7+19ubuntu14 all [installed,local]
x11proto-core-dev/now 2019.2-1ubuntu1 all [installed,local]
x11proto-dev/now 2019.2-1ubuntu1 all [installed,local]
x11proto-xext-dev/now 2019.2-1ubuntu1 all [installed,local]
xdg-utils/now 1.1.3-2ubuntu1.20.04.2 all [installed,local]
xfonts-encodings/now 1:1.0.5-0ubuntu1 all [installed,local]
xfonts-utils/now 1:7.7+6 amd64 [installed,local]
xkb-data/now 2.29-2 all [installed,local]
xorg-sgml-doctools/now 1:1.11-1 all [installed,local]
xtrans-dev/now 1.4.0-1 all [installed,local]
xxd/now 2:8.1.2269-1ubuntu5 amd64 [installed,local]
zlib1g/now 1:1.2.11.dfsg-2ubuntu1.2 amd64 [installed,local]
```
</details>